# เงินกู้แพร่ — สร้าง APK ด้วยมือถือ

1. ดาวน์โหลด ZIP นี้
2. เปิด GitHub ใน Chrome
3. สร้าง Repository ใหม่ เช่น `ngoenkoo-phrae`
4. แตก ZIP แล้วอัปโหลดไฟล์ทั้งหมดเข้า Repository
5. เข้าแท็บ **Actions**
6. เลือก **Build APK**
7. กด **Run workflow**
8. รอจนขึ้นเครื่องหมายเขียว
9. เปิดรายการงาน แล้วดาวน์โหลด Artifact `ngoenkoo-phrae-debug`
10. แตกไฟล์ ZIP ของ Artifact แล้วติดตั้ง `app-debug.apk`

หมายเหตุ:
- โปรเจกต์นี้ไม่ใช้ Hatchable
- ตอนนี้เป็นโครง Android พร้อมระบบ Build APK จากมือถือ
- จุดเชื่อม Supabase และการย้ายข้อมูลจริงจะเป็นขั้นต่อไป
- ไม่ได้ใส่ประวัติการจ่ายเงินเก่า
