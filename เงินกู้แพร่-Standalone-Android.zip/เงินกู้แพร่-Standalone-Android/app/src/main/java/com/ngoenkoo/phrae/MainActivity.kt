package com.ngenkoo.phrae

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.*
import android.widget.*
import android.content.*
import android.net.Uri

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build()
    }
    private fun build() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28,28,28,28)
        }
        val title = TextView(this).apply {
            text = "💰 เงินกู้แพร่"
            textSize = 28f
            setTextColor(Color.rgb(108,52,131))
        }
        page.addView(title)
        val sub = TextView(this).apply {
            text = "Standalone Android • ไม่ใช้ Hatchable"
            textSize = 15f
        }
        page.addView(sub)
        val search = EditText(this).apply {
            hint = "ค้นหาลูกค้า..."
            setSingleLine(true)
        }
        page.addView(search)
        val add = Button(this).apply {
            text = "➕ เพิ่มลูกค้า"
            setOnClickListener { addCustomerDialog() }
        }
        page.addView(add)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(list)
        scroll.addView(page)
        setContentView(scroll)
        showDemo()
    }
    private fun showDemo() {
        list.removeAllViews()
        val demo = listOf(
            Triple("ป้าภาพ", "โต๊ะ 1 • ฿100/วัน", "ครบ"),
            Triple("ป้าโสภาน้ำชำ", "โต๊ะ 1 • ฿200/วัน", "ครบ"),
            Triple("ลูกค้าตัวอย่าง", "โต๊ะ 2 • ฿150/วัน", "ยังไม่ชำระ")
        )
        demo.forEach { c ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(20,20,20,20)
            }
            val t = TextView(this).apply { text="${c.first}\n${c.second}\nสถานะ: ${c.third}"; textSize=17f }
            box.addView(t)
            val row = LinearLayout(this)
            val call = Button(this).apply {
                text="📞 โทร"
                setOnClickListener { Toast.makeText(this@MainActivity,"กรุณาใส่เบอร์ลูกค้าในข้อมูลลูกค้า",Toast.LENGTH_SHORT).show() }
            }
            val map = Button(this).apply {
                text="🗺️ นำทาง"
                setOnClickListener {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="+Uri.encode(c.first))))
                }
            }
            row.addView(call, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(map, LinearLayout.LayoutParams(0, -2, 1f))
            box.addView(row)
            list.addView(box)
        }
    }
    private fun addCustomerDialog() {
        val input = EditText(this).apply { hint="ชื่อลูกค้า" }
        AlertDialog.Builder(this)
            .setTitle("เพิ่มลูกค้า")
            .setView(input)
            .setPositiveButton("บันทึก") { _, _ ->
                if (input.text.isNotBlank()) Toast.makeText(this,"บันทึก ${input.text}",Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("ยกเลิก", null).show()
    }
}
